﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestAppForDotCoverTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Assert.IsTrue(true);
        }
    }
}
