﻿using System;

namespace TestAppForDotCover
{
    public class Class1
    {
    }
}
