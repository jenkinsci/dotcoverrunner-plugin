﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AnotherAppTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
